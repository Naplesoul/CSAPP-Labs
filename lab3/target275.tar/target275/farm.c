/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_313(unsigned x)
{
    return x + 3347662984U;
}

void setval_439(unsigned *p)
{
    *p = 3284633944U;
}

unsigned addval_421(unsigned x)
{
    return x + 2076414296U;
}

void setval_388(unsigned *p)
{
    *p = 1321439320U;
}

unsigned getval_428()
{
    return 2421743581U;
}

void setval_277(unsigned *p)
{
    *p = 2421224373U;
}

unsigned getval_463()
{
    return 2462550344U;
}

unsigned addval_162(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_179(unsigned x)
{
    return x + 3285617454U;
}

unsigned getval_255()
{
    return 3676362393U;
}

unsigned addval_387(unsigned x)
{
    return x + 3223901833U;
}

unsigned addval_250(unsigned x)
{
    return x + 3281049225U;
}

unsigned getval_281()
{
    return 3682124169U;
}

void setval_437(unsigned *p)
{
    *p = 3286272360U;
}

void setval_349(unsigned *p)
{
    *p = 3677932173U;
}

void setval_389(unsigned *p)
{
    *p = 3372269961U;
}

unsigned getval_362()
{
    return 3284240529U;
}

unsigned getval_298()
{
    return 3682912905U;
}

unsigned getval_215()
{
    return 3224947336U;
}

unsigned addval_364(unsigned x)
{
    return x + 3536115337U;
}

unsigned addval_316(unsigned x)
{
    return x + 3285633459U;
}

void setval_232(unsigned *p)
{
    *p = 2430634328U;
}

void setval_333(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_378()
{
    return 3372794249U;
}

void setval_458(unsigned *p)
{
    *p = 2425405837U;
}

unsigned getval_297()
{
    return 3682912904U;
}

unsigned addval_382(unsigned x)
{
    return x + 3223896457U;
}

unsigned addval_103(unsigned x)
{
    return x + 3523794569U;
}

unsigned addval_148(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_262()
{
    return 3685010057U;
}

void setval_480(unsigned *p)
{
    *p = 3531920905U;
}

void setval_432(unsigned *p)
{
    *p = 3223374473U;
}

void setval_230(unsigned *p)
{
    *p = 3286272264U;
}

unsigned getval_495()
{
    return 3380920713U;
}

void setval_286(unsigned *p)
{
    *p = 3375942285U;
}

unsigned getval_245()
{
    return 2430634312U;
}

unsigned addval_267(unsigned x)
{
    return x + 3524840073U;
}

unsigned addval_422(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_155()
{
    return 3286272328U;
}

unsigned getval_172()
{
    return 3383017865U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
